class SeriesApi(Resource):
    def get(self):
        buses = Bus.objects().to_json()
        return Response(buses, mimetype="application/json", status=200)

    def post(self):
        body = request.get_json()
        bus = Bus(**body).save()
        id = bus.id
        return {'id': str(id)}, 200